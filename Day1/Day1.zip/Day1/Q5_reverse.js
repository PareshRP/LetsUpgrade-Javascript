//Print an array in reverse order
var array = [10, 20, 45, 5, 35];
console.log(array.reverse());
