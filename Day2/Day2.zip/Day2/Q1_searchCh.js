//Program to search for a particular  character in a string
var name = "Paresh";
var ch = name.charAt(3)
console.log(ch);