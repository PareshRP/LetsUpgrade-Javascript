//Program to search for a element in a array of strings 
var array = ['Ross', 'Rachael', 'Joey', 'Monica']; 
var num = array.indexOf("Rachael")
console.log(num + " " + array[num]);