//Program to display only elements containing 'a' in them from a array
const array = ['Ross', 'Rachael', 'Joey', 'Monica'];
const a = array.filter(s => s.includes('a'));
console.log(a);