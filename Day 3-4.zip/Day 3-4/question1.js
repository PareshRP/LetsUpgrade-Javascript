function firstImage() {
    const first = document.getElementById("img1");
    const newUrl = "https://obxartstudio.com/wp-content/uploads/2016/10/Art.jpg";

    first.src = newUrl;
}

function secondImage() {
    const second = document.getElementById("img1");
    const newUrl = "https://mymodernmet.com/wp/wp-content/uploads/2019/03/elements-of-art-large.jpg";
    
    second.src = newUrl;
}

function thirdImage() {
    const third = document.getElementById("img1");
    const newUrl = "https://www.oxy.edu/sites/default/files/landing-page/banner-images/art-art-history_main_1440x800.jpg";
    
    third.src = newUrl;
}