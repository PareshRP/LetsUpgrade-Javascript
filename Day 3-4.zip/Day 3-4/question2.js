function textCopy() {
    const ele = document.getElementById("input2");
    const eles = document.getElementById("input1");
    
    console.log(ele.value = eles.value);
}